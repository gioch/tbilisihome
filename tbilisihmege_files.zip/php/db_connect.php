<?
 
$Database = mysql_connect("localhost","username","login");
mysql_select_db("database_name", $Database);

mysql_query( 'SET NAMES utf8' ); 

?>